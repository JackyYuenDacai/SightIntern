﻿namespace UHFReader09demomain
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.TabSheet_CMD = new System.Windows.Forms.TabPage();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.button6 = new System.Windows.Forms.Button();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label39 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label38 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label37 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox30 = new System.Windows.Forms.GroupBox();
            this.radioButton_band5 = new System.Windows.Forms.RadioButton();
            this.radioButton_band4 = new System.Windows.Forms.RadioButton();
            this.radioButton_band3 = new System.Windows.Forms.RadioButton();
            this.radioButton_band2 = new System.Windows.Forms.RadioButton();
            this.radioButton_band1 = new System.Windows.Forms.RadioButton();
            this.Button1 = new System.Windows.Forms.Button();
            this.Button5 = new System.Windows.Forms.Button();
            this.ComboBox_scantime = new System.Windows.Forms.ComboBox();
            this.ComboBox_baud = new System.Windows.Forms.ComboBox();
            this.CheckBox_SameFre = new System.Windows.Forms.CheckBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.ComboBox_dmaxfre = new System.Windows.Forms.ComboBox();
            this.ComboBox_dminfre = new System.Windows.Forms.ComboBox();
            this.ComboBox_PowerDbm = new System.Windows.Forms.ComboBox();
            this.Edit_NewComAdr = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Button3 = new System.Windows.Forms.Button();
            this.Edit_scantime = new System.Windows.Forms.TextBox();
            this.EPCC1G2 = new System.Windows.Forms.CheckBox();
            this.ISO180006B = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.Edit_dmaxfre = new System.Windows.Forms.TextBox();
            this.Edit_powerdBm = new System.Windows.Forms.TextBox();
            this.Edit_Version = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Edit_dminfre = new System.Windows.Forms.TextBox();
            this.Edit_ComAdr = new System.Windows.Forms.TextBox();
            this.Edit_Type = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.ComboBox_baud2 = new System.Windows.Forms.ComboBox();
            this.label47 = new System.Windows.Forms.Label();
            this.ComboBox_AlreadyOpenCOM = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ClosePort = new System.Windows.Forms.Button();
            this.OpenPort = new System.Windows.Forms.Button();
            this.Edit_CmdComAddr = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.ComboBox_COM = new System.Windows.Forms.ComboBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.TabSheet_EPCC1G2 = new System.Windows.Forms.TabPage();
            this.groupBox31 = new System.Windows.Forms.GroupBox();
            this.maskLen_textBox = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.maskadr_textbox = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.Button_LockUserBlock_G2 = new System.Windows.Forms.Button();
            this.Edit_AccessCode6 = new System.Windows.Forms.TextBox();
            this.ComboBox_BlockNum = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.ComboBox_EPC6 = new System.Windows.Forms.ComboBox();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.Label_Alarm = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.Button_SetEASAlarm_G2 = new System.Windows.Forms.Button();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.NoAlarm_G2 = new System.Windows.Forms.RadioButton();
            this.Alarm_G2 = new System.Windows.Forms.RadioButton();
            this.Edit_AccessCode5 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.ComboBox_EPC5 = new System.Windows.Forms.ComboBox();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.Button_CheckReadProtected_G2 = new System.Windows.Forms.Button();
            this.Button_RemoveReadProtect_G2 = new System.Windows.Forms.Button();
            this.Button_SetMultiReadProtect_G2 = new System.Windows.Forms.Button();
            this.Button_SetReadProtect_G2 = new System.Windows.Forms.Button();
            this.Edit_AccessCode4 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.ComboBox_EPC4 = new System.Windows.Forms.ComboBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.Button_WriteEPC_G2 = new System.Windows.Forms.Button();
            this.Edit_AccessCode3 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.Edit_WriteEPC = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.Button_DestroyCard = new System.Windows.Forms.Button();
            this.Edit_DestroyCode = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.ComboBox_EPC3 = new System.Windows.Forms.ComboBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.CheckBox_TID = new System.Windows.Forms.CheckBox();
            this.groupBox33 = new System.Windows.Forms.GroupBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.ComboBox_IntervalTime = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.Button_SetProtectState = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.AlwaysNot2 = new System.Windows.Forms.RadioButton();
            this.Always2 = new System.Windows.Forms.RadioButton();
            this.Proect2 = new System.Windows.Forms.RadioButton();
            this.NoProect2 = new System.Windows.Forms.RadioButton();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.P_User = new System.Windows.Forms.RadioButton();
            this.P_TID = new System.Windows.Forms.RadioButton();
            this.P_EPC = new System.Windows.Forms.RadioButton();
            this.P_Reserve = new System.Windows.Forms.RadioButton();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.AlwaysNot = new System.Windows.Forms.RadioButton();
            this.Always = new System.Windows.Forms.RadioButton();
            this.Proect = new System.Windows.Forms.RadioButton();
            this.NoProect = new System.Windows.Forms.RadioButton();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.AccessCode = new System.Windows.Forms.RadioButton();
            this.DestroyCode = new System.Windows.Forms.RadioButton();
            this.ComboBox_EPC1 = new System.Windows.Forms.ComboBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.textBox_pc = new System.Windows.Forms.TextBox();
            this.checkBox_pc = new System.Windows.Forms.CheckBox();
            this.BlockWrite = new System.Windows.Forms.Button();
            this.ComboBox_EPC2 = new System.Windows.Forms.ComboBox();
            this.button7 = new System.Windows.Forms.Button();
            this.Button_BlockErase = new System.Windows.Forms.Button();
            this.Button_DataWrite = new System.Windows.Forms.Button();
            this.SpeedButton_Read_G2 = new System.Windows.Forms.Button();
            this.Edit_WriteData = new System.Windows.Forms.TextBox();
            this.Edit_AccessCode2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Edit_WordPtr = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.C_User = new System.Windows.Forms.RadioButton();
            this.C_TID = new System.Windows.Forms.RadioButton();
            this.C_EPC = new System.Windows.Forms.RadioButton();
            this.C_Reserve = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.ListView1_EPC = new System.Windows.Forms.ListView();
            this.listViewCol_Number = new System.Windows.Forms.ColumnHeader();
            this.listViewCol_ID = new System.Windows.Forms.ColumnHeader();
            this.listViewCol_Length = new System.Windows.Forms.ColumnHeader();
            this.listViewCol_Times = new System.Windows.Forms.ColumnHeader();
            this.TabSheet_6B = new System.Windows.Forms.TabPage();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.Edit_WriteData_6B = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.Button22 = new System.Windows.Forms.Button();
            this.Button15 = new System.Windows.Forms.Button();
            this.Button14 = new System.Windows.Forms.Button();
            this.SpeedButton_Write_6B = new System.Windows.Forms.Button();
            this.SpeedButton_Read_6B = new System.Windows.Forms.Button();
            this.Edit_Len_6B = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.Edit_StartAddress_6B = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.ComboBox_ID1_6B = new System.Windows.Forms.ComboBox();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.Edit_ConditionContent_6B = new System.Windows.Forms.TextBox();
            this.Edit_Query_StartAddress_6B = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.Greater_6B = new System.Windows.Forms.RadioButton();
            this.Less_6B = new System.Windows.Forms.RadioButton();
            this.Different_6B = new System.Windows.Forms.RadioButton();
            this.Same_6B = new System.Windows.Forms.RadioButton();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.SpeedButton_Query_6B = new System.Windows.Forms.Button();
            this.Bycondition_6B = new System.Windows.Forms.RadioButton();
            this.Byone_6B = new System.Windows.Forms.RadioButton();
            this.ComboBox_IntervalTime_6B = new System.Windows.Forms.ComboBox();
            this.label31 = new System.Windows.Forms.Label();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.ListView_ID_6B = new System.Windows.Forms.ListView();
            this.columnHeader5 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader6 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader7 = new System.Windows.Forms.ColumnHeader();
            this.StatusBar1 = new System.Windows.Forms.StatusBar();
            this.TStatusPanel = new System.Windows.Forms.StatusBarPanel();
            this.Port = new System.Windows.Forms.StatusBarPanel();
            this.Manufacturername = new System.Windows.Forms.StatusBarPanel();
            this.Timer_Test_ = new System.Windows.Forms.Timer(this.components);
            this.Timer_G2_Read = new System.Windows.Forms.Timer(this.components);
            this.Timer_G2_Alarm = new System.Windows.Forms.Timer(this.components);
            this.Timer_Test_6B = new System.Windows.Forms.Timer(this.components);
            this.Timer_6B_Read = new System.Windows.Forms.Timer(this.components);
            this.Timer_6B_Write = new System.Windows.Forms.Timer(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tabControl1.SuspendLayout();
            this.TabSheet_CMD.SuspendLayout();
            this.groupBox24.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox30.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.GroupBox1.SuspendLayout();
            this.TabSheet_EPCC1G2.SuspendLayout();
            this.groupBox31.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox33.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.TabSheet_6B.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.groupBox19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TStatusPanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Port)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Manufacturername)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.TabSheet_CMD);
            this.tabControl1.Controls.Add(this.TabSheet_EPCC1G2);
            this.tabControl1.Controls.Add(this.TabSheet_6B);
            this.tabControl1.Location = new System.Drawing.Point(2, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(825, 650);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl1_Selecting);
            // 
            // TabSheet_CMD
            // 
            this.TabSheet_CMD.BackColor = System.Drawing.Color.Transparent;
            this.TabSheet_CMD.Controls.Add(this.groupBox24);
            this.TabSheet_CMD.Controls.Add(this.groupBox23);
            this.TabSheet_CMD.Controls.Add(this.groupBox3);
            this.TabSheet_CMD.Controls.Add(this.progressBar1);
            this.TabSheet_CMD.Controls.Add(this.groupBox2);
            this.TabSheet_CMD.Controls.Add(this.GroupBox1);
            this.TabSheet_CMD.Location = new System.Drawing.Point(4, 21);
            this.TabSheet_CMD.Name = "TabSheet_CMD";
            this.TabSheet_CMD.Padding = new System.Windows.Forms.Padding(3);
            this.TabSheet_CMD.Size = new System.Drawing.Size(817, 625);
            this.TabSheet_CMD.TabIndex = 1;
            this.TabSheet_CMD.Text = "读写器参数设置";
            this.TabSheet_CMD.UseVisualStyleBackColor = true;
            // 
            // groupBox24
            // 
            this.groupBox24.Controls.Add(this.button9);
            this.groupBox24.Controls.Add(this.button8);
            this.groupBox24.Controls.Add(this.radioButton2);
            this.groupBox24.Controls.Add(this.radioButton1);
            this.groupBox24.Location = new System.Drawing.Point(557, 289);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Size = new System.Drawing.Size(200, 130);
            this.groupBox24.TabIndex = 45;
            this.groupBox24.TabStop = false;
            this.groupBox24.Text = "蜂鸣器开关";
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(103, 73);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(69, 23);
            this.button9.TabIndex = 16;
            this.button9.Text = "读取";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(15, 74);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(69, 23);
            this.button8.TabIndex = 15;
            this.button8.Text = "设置";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(101, 44);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(35, 16);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.Text = "关";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(31, 42);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(35, 16);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "开";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // groupBox23
            // 
            this.groupBox23.Controls.Add(this.button6);
            this.groupBox23.Controls.Add(this.comboBox3);
            this.groupBox23.Controls.Add(this.label39);
            this.groupBox23.Controls.Add(this.comboBox2);
            this.groupBox23.Controls.Add(this.label38);
            this.groupBox23.Controls.Add(this.comboBox1);
            this.groupBox23.Controls.Add(this.label37);
            this.groupBox23.Location = new System.Drawing.Point(147, 289);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Size = new System.Drawing.Size(402, 130);
            this.groupBox23.TabIndex = 44;
            this.groupBox23.TabStop = false;
            this.groupBox23.Text = "声光控制";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(270, 23);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(121, 23);
            this.button6.TabIndex = 14;
            this.button6.Text = "设置";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // comboBox3
            // 
            this.comboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(155, 95);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(107, 20);
            this.comboBox3.TabIndex = 5;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(18, 100);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(131, 12);
            this.label39.TabIndex = 4;
            this.label39.Text = "灯亮和蜂鸣器执行次数:";
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(155, 58);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(107, 20);
            this.comboBox2.TabIndex = 3;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(18, 63);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(131, 12);
            this.label38.TabIndex = 2;
            this.label38.Text = "灯亮和蜂鸣器静默时间:";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(155, 23);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(107, 20);
            this.comboBox1.TabIndex = 1;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(18, 28);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(131, 12);
            this.label37.TabIndex = 0;
            this.label37.Text = "灯亮和蜂鸣器鸣叫时间:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox30);
            this.groupBox3.Controls.Add(this.Button1);
            this.groupBox3.Controls.Add(this.Button5);
            this.groupBox3.Controls.Add(this.ComboBox_scantime);
            this.groupBox3.Controls.Add(this.ComboBox_baud);
            this.groupBox3.Controls.Add(this.CheckBox_SameFre);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.ComboBox_dmaxfre);
            this.groupBox3.Controls.Add(this.ComboBox_dminfre);
            this.groupBox3.Controls.Add(this.ComboBox_PowerDbm);
            this.groupBox3.Controls.Add(this.Edit_NewComAdr);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Location = new System.Drawing.Point(147, 128);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(663, 155);
            this.groupBox3.TabIndex = 42;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "设置读写器参数";
            // 
            // groupBox30
            // 
            this.groupBox30.Controls.Add(this.radioButton_band5);
            this.groupBox30.Controls.Add(this.radioButton_band4);
            this.groupBox30.Controls.Add(this.radioButton_band3);
            this.groupBox30.Controls.Add(this.radioButton_band2);
            this.groupBox30.Controls.Add(this.radioButton_band1);
            this.groupBox30.Location = new System.Drawing.Point(475, 11);
            this.groupBox30.Name = "groupBox30";
            this.groupBox30.Size = new System.Drawing.Size(180, 108);
            this.groupBox30.TabIndex = 44;
            this.groupBox30.TabStop = false;
            this.groupBox30.Text = "频段选择";
            this.groupBox30.Enter += new System.EventHandler(this.groupBox30_Enter);
            // 
            // radioButton_band5
            // 
            this.radioButton_band5.AutoSize = true;
            this.radioButton_band5.Location = new System.Drawing.Point(6, 86);
            this.radioButton_band5.Name = "radioButton_band5";
            this.radioButton_band5.Size = new System.Drawing.Size(65, 16);
            this.radioButton_band5.TabIndex = 4;
            this.radioButton_band5.TabStop = true;
            this.radioButton_band5.Text = "EU band";
            this.radioButton_band5.UseVisualStyleBackColor = true;
            this.radioButton_band5.CheckedChanged += new System.EventHandler(this.radioButton_band5_CheckedChanged);
            // 
            // radioButton_band4
            // 
            this.radioButton_band4.AutoSize = true;
            this.radioButton_band4.Location = new System.Drawing.Point(6, 68);
            this.radioButton_band4.Name = "radioButton_band4";
            this.radioButton_band4.Size = new System.Drawing.Size(89, 16);
            this.radioButton_band4.TabIndex = 3;
            this.radioButton_band4.TabStop = true;
            this.radioButton_band4.Text = "Korean band";
            this.radioButton_band4.UseVisualStyleBackColor = true;
            this.radioButton_band4.CheckedChanged += new System.EventHandler(this.radioButton_band4_CheckedChanged);
            // 
            // radioButton_band3
            // 
            this.radioButton_band3.AutoSize = true;
            this.radioButton_band3.Location = new System.Drawing.Point(6, 50);
            this.radioButton_band3.Name = "radioButton_band3";
            this.radioButton_band3.Size = new System.Drawing.Size(65, 16);
            this.radioButton_band3.TabIndex = 2;
            this.radioButton_band3.TabStop = true;
            this.radioButton_band3.Text = "US band";
            this.radioButton_band3.UseVisualStyleBackColor = true;
            this.radioButton_band3.CheckedChanged += new System.EventHandler(this.radioButton_band3_CheckedChanged);
            // 
            // radioButton_band2
            // 
            this.radioButton_band2.AutoSize = true;
            this.radioButton_band2.Location = new System.Drawing.Point(6, 31);
            this.radioButton_band2.Name = "radioButton_band2";
            this.radioButton_band2.Size = new System.Drawing.Size(101, 16);
            this.radioButton_band2.TabIndex = 1;
            this.radioButton_band2.TabStop = true;
            this.radioButton_band2.Text = "Chinese band2";
            this.radioButton_band2.UseVisualStyleBackColor = true;
            this.radioButton_band2.CheckedChanged += new System.EventHandler(this.radioButton_band2_CheckedChanged);
            // 
            // radioButton_band1
            // 
            this.radioButton_band1.AutoSize = true;
            this.radioButton_band1.Location = new System.Drawing.Point(6, 13);
            this.radioButton_band1.Name = "radioButton_band1";
            this.radioButton_band1.Size = new System.Drawing.Size(77, 16);
            this.radioButton_band1.TabIndex = 0;
            this.radioButton_band1.TabStop = true;
            this.radioButton_band1.Text = "User band";
            this.radioButton_band1.UseVisualStyleBackColor = true;
            this.radioButton_band1.CheckedChanged += new System.EventHandler(this.radioButton_band1_CheckedChanged);
            // 
            // Button1
            // 
            this.Button1.Location = new System.Drawing.Point(538, 125);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(118, 23);
            this.Button1.TabIndex = 14;
            this.Button1.Text = "恢复出厂参数";
            this.Button1.UseVisualStyleBackColor = true;
            this.Button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // Button5
            // 
            this.Button5.Location = new System.Drawing.Point(404, 125);
            this.Button5.Name = "Button5";
            this.Button5.Size = new System.Drawing.Size(121, 23);
            this.Button5.TabIndex = 13;
            this.Button5.Text = "设置参数";
            this.Button5.UseVisualStyleBackColor = true;
            this.Button5.Click += new System.EventHandler(this.Button5_Click);
            // 
            // ComboBox_scantime
            // 
            this.ComboBox_scantime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_scantime.FormattingEnabled = true;
            this.ComboBox_scantime.Location = new System.Drawing.Point(348, 55);
            this.ComboBox_scantime.Name = "ComboBox_scantime";
            this.ComboBox_scantime.Size = new System.Drawing.Size(121, 20);
            this.ComboBox_scantime.TabIndex = 12;
            // 
            // ComboBox_baud
            // 
            this.ComboBox_baud.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_baud.FormattingEnabled = true;
            this.ComboBox_baud.Items.AddRange(new object[] {
            "9600bps",
            "19200bps",
            "38400bps",
            "57600bps",
            "115200bps"});
            this.ComboBox_baud.Location = new System.Drawing.Point(348, 20);
            this.ComboBox_baud.Name = "ComboBox_baud";
            this.ComboBox_baud.Size = new System.Drawing.Size(121, 20);
            this.ComboBox_baud.TabIndex = 11;
            // 
            // CheckBox_SameFre
            // 
            this.CheckBox_SameFre.AutoSize = true;
            this.CheckBox_SameFre.Location = new System.Drawing.Point(215, 94);
            this.CheckBox_SameFre.Name = "CheckBox_SameFre";
            this.CheckBox_SameFre.Size = new System.Drawing.Size(60, 16);
            this.CheckBox_SameFre.TabIndex = 10;
            this.CheckBox_SameFre.Text = "单频点";
            this.CheckBox_SameFre.UseVisualStyleBackColor = true;
            this.CheckBox_SameFre.CheckedChanged += new System.EventHandler(this.CheckBox_SameFre_CheckedChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(213, 58);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(131, 12);
            this.label17.TabIndex = 9;
            this.label17.Text = "询查命令最大响应时间:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(213, 27);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(47, 12);
            this.label16.TabIndex = 8;
            this.label16.Text = "波特率:";
            // 
            // ComboBox_dmaxfre
            // 
            this.ComboBox_dmaxfre.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_dmaxfre.FormattingEnabled = true;
            this.ComboBox_dmaxfre.Location = new System.Drawing.Point(95, 127);
            this.ComboBox_dmaxfre.Name = "ComboBox_dmaxfre";
            this.ComboBox_dmaxfre.Size = new System.Drawing.Size(100, 20);
            this.ComboBox_dmaxfre.TabIndex = 7;
            this.ComboBox_dmaxfre.SelectedIndexChanged += new System.EventHandler(this.ComboBox_dfreSelect);
            // 
            // ComboBox_dminfre
            // 
            this.ComboBox_dminfre.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_dminfre.FormattingEnabled = true;
            this.ComboBox_dminfre.Location = new System.Drawing.Point(95, 92);
            this.ComboBox_dminfre.Name = "ComboBox_dminfre";
            this.ComboBox_dminfre.Size = new System.Drawing.Size(100, 20);
            this.ComboBox_dminfre.TabIndex = 6;
            this.ComboBox_dminfre.SelectedIndexChanged += new System.EventHandler(this.ComboBox_dfreSelect);
            // 
            // ComboBox_PowerDbm
            // 
            this.ComboBox_PowerDbm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_PowerDbm.FormattingEnabled = true;
            this.ComboBox_PowerDbm.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13"});
            this.ComboBox_PowerDbm.Location = new System.Drawing.Point(95, 55);
            this.ComboBox_PowerDbm.Name = "ComboBox_PowerDbm";
            this.ComboBox_PowerDbm.Size = new System.Drawing.Size(100, 20);
            this.ComboBox_PowerDbm.TabIndex = 5;
            // 
            // Edit_NewComAdr
            // 
            this.Edit_NewComAdr.Location = new System.Drawing.Point(95, 20);
            this.Edit_NewComAdr.MaxLength = 2;
            this.Edit_NewComAdr.Name = "Edit_NewComAdr";
            this.Edit_NewComAdr.Size = new System.Drawing.Size(100, 21);
            this.Edit_NewComAdr.TabIndex = 4;
            this.Edit_NewComAdr.Text = "00";
            this.Edit_NewComAdr.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 130);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(59, 12);
            this.label15.TabIndex = 3;
            this.label15.Text = "最高频率:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 95);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(59, 12);
            this.label14.TabIndex = 2;
            this.label14.Text = "最低频率:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 58);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(35, 12);
            this.label13.TabIndex = 1;
            this.label13.Text = "功率:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 27);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 12);
            this.label12.TabIndex = 0;
            this.label12.Text = "地址(HEX):";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(242, 306);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(399, 23);
            this.progressBar1.TabIndex = 43;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Button3);
            this.groupBox2.Controls.Add(this.Edit_scantime);
            this.groupBox2.Controls.Add(this.EPCC1G2);
            this.groupBox2.Controls.Add(this.ISO180006B);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.Edit_dmaxfre);
            this.groupBox2.Controls.Add(this.Edit_powerdBm);
            this.groupBox2.Controls.Add(this.Edit_Version);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.Edit_dminfre);
            this.groupBox2.Controls.Add(this.Edit_ComAdr);
            this.groupBox2.Controls.Add(this.Edit_Type);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(147, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(663, 119);
            this.groupBox2.TabIndex = 41;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "读写器信息";
            // 
            // Button3
            // 
            this.Button3.Location = new System.Drawing.Point(538, 90);
            this.Button3.Name = "Button3";
            this.Button3.Size = new System.Drawing.Size(118, 23);
            this.Button3.TabIndex = 17;
            this.Button3.Text = "获取读写器信息";
            this.Button3.UseVisualStyleBackColor = true;
            this.Button3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // Edit_scantime
            // 
            this.Edit_scantime.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Edit_scantime.Location = new System.Drawing.Point(538, 54);
            this.Edit_scantime.Name = "Edit_scantime";
            this.Edit_scantime.Size = new System.Drawing.Size(118, 21);
            this.Edit_scantime.TabIndex = 16;
            // 
            // EPCC1G2
            // 
            this.EPCC1G2.AutoSize = true;
            this.EPCC1G2.Location = new System.Drawing.Point(538, 32);
            this.EPCC1G2.Name = "EPCC1G2";
            this.EPCC1G2.Size = new System.Drawing.Size(72, 16);
            this.EPCC1G2.TabIndex = 15;
            this.EPCC1G2.Text = "EPCC1-G2";
            this.EPCC1G2.UseVisualStyleBackColor = true;
            // 
            // ISO180006B
            // 
            this.ISO180006B.AutoSize = true;
            this.ISO180006B.Location = new System.Drawing.Point(538, 13);
            this.ISO180006B.Name = "ISO180006B";
            this.ISO180006B.Size = new System.Drawing.Size(90, 16);
            this.ISO180006B.TabIndex = 14;
            this.ISO180006B.Text = "ISO18000-6B";
            this.ISO180006B.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(402, 58);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(125, 12);
            this.label11.TabIndex = 13;
            this.label11.Text = "询查命令最大响应时间";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(402, 21);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 12);
            this.label10.TabIndex = 12;
            this.label10.Text = "支持协议:";
            // 
            // Edit_dmaxfre
            // 
            this.Edit_dmaxfre.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Edit_dmaxfre.Location = new System.Drawing.Point(286, 92);
            this.Edit_dmaxfre.Name = "Edit_dmaxfre";
            this.Edit_dmaxfre.Size = new System.Drawing.Size(100, 21);
            this.Edit_dmaxfre.TabIndex = 11;
            // 
            // Edit_powerdBm
            // 
            this.Edit_powerdBm.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Edit_powerdBm.Location = new System.Drawing.Point(286, 55);
            this.Edit_powerdBm.Name = "Edit_powerdBm";
            this.Edit_powerdBm.Size = new System.Drawing.Size(100, 21);
            this.Edit_powerdBm.TabIndex = 10;
            // 
            // Edit_Version
            // 
            this.Edit_Version.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Edit_Version.Location = new System.Drawing.Point(286, 18);
            this.Edit_Version.Name = "Edit_Version";
            this.Edit_Version.Size = new System.Drawing.Size(100, 21);
            this.Edit_Version.TabIndex = 9;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(197, 95);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 12);
            this.label9.TabIndex = 8;
            this.label9.Text = "最高频率：";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(197, 58);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 12);
            this.label8.TabIndex = 7;
            this.label8.Text = "功率:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(197, 21);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 12);
            this.label7.TabIndex = 6;
            this.label7.Text = "版本:";
            // 
            // Edit_dminfre
            // 
            this.Edit_dminfre.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Edit_dminfre.Location = new System.Drawing.Point(95, 92);
            this.Edit_dminfre.Name = "Edit_dminfre";
            this.Edit_dminfre.Size = new System.Drawing.Size(85, 21);
            this.Edit_dminfre.TabIndex = 5;
            // 
            // Edit_ComAdr
            // 
            this.Edit_ComAdr.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Edit_ComAdr.Location = new System.Drawing.Point(95, 55);
            this.Edit_ComAdr.Name = "Edit_ComAdr";
            this.Edit_ComAdr.Size = new System.Drawing.Size(85, 21);
            this.Edit_ComAdr.TabIndex = 4;
            // 
            // Edit_Type
            // 
            this.Edit_Type.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Edit_Type.Location = new System.Drawing.Point(95, 18);
            this.Edit_Type.Name = "Edit_Type";
            this.Edit_Type.Size = new System.Drawing.Size(85, 21);
            this.Edit_Type.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 95);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 12);
            this.label6.TabIndex = 2;
            this.label6.Text = "最低频率：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 58);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 12);
            this.label5.TabIndex = 1;
            this.label5.Text = "地址:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "型号:";
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.ComboBox_baud2);
            this.GroupBox1.Controls.Add(this.label47);
            this.GroupBox1.Controls.Add(this.ComboBox_AlreadyOpenCOM);
            this.GroupBox1.Controls.Add(this.label3);
            this.GroupBox1.Controls.Add(this.ClosePort);
            this.GroupBox1.Controls.Add(this.OpenPort);
            this.GroupBox1.Controls.Add(this.Edit_CmdComAddr);
            this.GroupBox1.Controls.Add(this.Label2);
            this.GroupBox1.Controls.Add(this.ComboBox_COM);
            this.GroupBox1.Controls.Add(this.Label1);
            this.GroupBox1.Location = new System.Drawing.Point(5, 6);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(136, 206);
            this.GroupBox1.TabIndex = 40;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "通讯";
            // 
            // ComboBox_baud2
            // 
            this.ComboBox_baud2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_baud2.FormattingEnabled = true;
            this.ComboBox_baud2.Items.AddRange(new object[] {
            "9600bps",
            "19200bps",
            "38400bps",
            "57600bps",
            "115200bps"});
            this.ComboBox_baud2.Location = new System.Drawing.Point(7, 110);
            this.ComboBox_baud2.Name = "ComboBox_baud2";
            this.ComboBox_baud2.Size = new System.Drawing.Size(121, 20);
            this.ComboBox_baud2.TabIndex = 12;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(6, 95);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(47, 12);
            this.label47.TabIndex = 9;
            this.label47.Text = "波特率:";
            // 
            // ComboBox_AlreadyOpenCOM
            // 
            this.ComboBox_AlreadyOpenCOM.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_AlreadyOpenCOM.FormattingEnabled = true;
            this.ComboBox_AlreadyOpenCOM.Location = new System.Drawing.Point(5, 153);
            this.ComboBox_AlreadyOpenCOM.Name = "ComboBox_AlreadyOpenCOM";
            this.ComboBox_AlreadyOpenCOM.Size = new System.Drawing.Size(125, 20);
            this.ComboBox_AlreadyOpenCOM.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 136);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 12);
            this.label3.TabIndex = 6;
            this.label3.Text = "已打开端口:";
            // 
            // ClosePort
            // 
            this.ClosePort.Location = new System.Drawing.Point(5, 177);
            this.ClosePort.Name = "ClosePort";
            this.ClosePort.Size = new System.Drawing.Size(125, 23);
            this.ClosePort.TabIndex = 5;
            this.ClosePort.Text = "关闭端口";
            this.ClosePort.UseVisualStyleBackColor = true;
            this.ClosePort.Click += new System.EventHandler(this.ClosePort_Click);
            // 
            // OpenPort
            // 
            this.OpenPort.Location = new System.Drawing.Point(5, 66);
            this.OpenPort.Name = "OpenPort";
            this.OpenPort.Size = new System.Drawing.Size(125, 23);
            this.OpenPort.TabIndex = 4;
            this.OpenPort.Text = "打开端口";
            this.OpenPort.UseVisualStyleBackColor = true;
            this.OpenPort.Click += new System.EventHandler(this.OpenPort_Click);
            // 
            // Edit_CmdComAddr
            // 
            this.Edit_CmdComAddr.BackColor = System.Drawing.SystemColors.Window;
            this.Edit_CmdComAddr.Location = new System.Drawing.Point(98, 39);
            this.Edit_CmdComAddr.MaxLength = 2;
            this.Edit_CmdComAddr.Name = "Edit_CmdComAddr";
            this.Edit_CmdComAddr.Size = new System.Drawing.Size(32, 21);
            this.Edit_CmdComAddr.TabIndex = 3;
            this.Edit_CmdComAddr.Text = "FF";
            this.Edit_CmdComAddr.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(6, 42);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(71, 12);
            this.Label2.TabIndex = 2;
            this.Label2.Text = "读写器地址:";
            // 
            // ComboBox_COM
            // 
            this.ComboBox_COM.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_COM.FormattingEnabled = true;
            this.ComboBox_COM.Location = new System.Drawing.Point(65, 13);
            this.ComboBox_COM.Name = "ComboBox_COM";
            this.ComboBox_COM.Size = new System.Drawing.Size(65, 20);
            this.ComboBox_COM.TabIndex = 1;
            this.ComboBox_COM.SelectedIndexChanged += new System.EventHandler(this.ComboBox_COM_SelectedIndexChanged);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(5, 21);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(41, 12);
            this.Label1.TabIndex = 0;
            this.Label1.Text = "端口：";
            // 
            // TabSheet_EPCC1G2
            // 
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox31);
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox18);
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox16);
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox15);
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox14);
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox13);
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox12);
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox7);
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox5);
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox4);
            this.TabSheet_EPCC1G2.Location = new System.Drawing.Point(4, 21);
            this.TabSheet_EPCC1G2.Name = "TabSheet_EPCC1G2";
            this.TabSheet_EPCC1G2.Size = new System.Drawing.Size(817, 625);
            this.TabSheet_EPCC1G2.TabIndex = 2;
            this.TabSheet_EPCC1G2.Text = "EPCC1-G2 Test";
            this.TabSheet_EPCC1G2.UseVisualStyleBackColor = true;
            // 
            // groupBox31
            // 
            this.groupBox31.Controls.Add(this.maskLen_textBox);
            this.groupBox31.Controls.Add(this.label44);
            this.groupBox31.Controls.Add(this.maskadr_textbox);
            this.groupBox31.Controls.Add(this.label43);
            this.groupBox31.Controls.Add(this.checkBox1);
            this.groupBox31.Location = new System.Drawing.Point(2, 162);
            this.groupBox31.Name = "groupBox31";
            this.groupBox31.Size = new System.Drawing.Size(479, 48);
            this.groupBox31.TabIndex = 9;
            this.groupBox31.TabStop = false;
            this.groupBox31.Text = "EPC掩模使能";
            // 
            // maskLen_textBox
            // 
            this.maskLen_textBox.Enabled = false;
            this.maskLen_textBox.Location = new System.Drawing.Point(412, 18);
            this.maskLen_textBox.Name = "maskLen_textBox";
            this.maskLen_textBox.Size = new System.Drawing.Size(56, 21);
            this.maskLen_textBox.TabIndex = 4;
            this.maskLen_textBox.Text = "00";
            this.maskLen_textBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_Len_6B_KeyPress);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(328, 23);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(77, 12);
            this.label44.TabIndex = 3;
            this.label44.Text = "掩模字节数：";
            // 
            // maskadr_textbox
            // 
            this.maskadr_textbox.Enabled = false;
            this.maskadr_textbox.Location = new System.Drawing.Point(214, 18);
            this.maskadr_textbox.Name = "maskadr_textbox";
            this.maskadr_textbox.Size = new System.Drawing.Size(50, 21);
            this.maskadr_textbox.TabIndex = 2;
            this.maskadr_textbox.Text = "00";
            this.maskadr_textbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_Len_6B_KeyPress);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(106, 23);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(113, 12);
            this.label43.TabIndex = 1;
            this.label43.Text = "掩模起始字节地址：";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Enabled = false;
            this.checkBox1.Location = new System.Drawing.Point(4, 22);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(48, 16);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "使能";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.Button_LockUserBlock_G2);
            this.groupBox18.Controls.Add(this.Edit_AccessCode6);
            this.groupBox18.Controls.Add(this.ComboBox_BlockNum);
            this.groupBox18.Controls.Add(this.label30);
            this.groupBox18.Controls.Add(this.label29);
            this.groupBox18.Controls.Add(this.ComboBox_EPC6);
            this.groupBox18.Location = new System.Drawing.Point(485, 532);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(325, 91);
            this.groupBox18.TabIndex = 8;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "锁定用户区数据块锁（永久锁定）";
            // 
            // Button_LockUserBlock_G2
            // 
            this.Button_LockUserBlock_G2.Location = new System.Drawing.Point(226, 62);
            this.Button_LockUserBlock_G2.Name = "Button_LockUserBlock_G2";
            this.Button_LockUserBlock_G2.Size = new System.Drawing.Size(89, 23);
            this.Button_LockUserBlock_G2.TabIndex = 5;
            this.Button_LockUserBlock_G2.Text = "锁定";
            this.Button_LockUserBlock_G2.UseVisualStyleBackColor = true;
            this.Button_LockUserBlock_G2.Click += new System.EventHandler(this.Button_LockUserBlock_G2_Click);
            // 
            // Edit_AccessCode6
            // 
            this.Edit_AccessCode6.Location = new System.Drawing.Point(134, 65);
            this.Edit_AccessCode6.MaxLength = 8;
            this.Edit_AccessCode6.Name = "Edit_AccessCode6";
            this.Edit_AccessCode6.Size = new System.Drawing.Size(85, 21);
            this.Edit_AccessCode6.TabIndex = 4;
            this.Edit_AccessCode6.Text = "00000000";
            this.Edit_AccessCode6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // ComboBox_BlockNum
            // 
            this.ComboBox_BlockNum.FormattingEnabled = true;
            this.ComboBox_BlockNum.Location = new System.Drawing.Point(134, 40);
            this.ComboBox_BlockNum.Name = "ComboBox_BlockNum";
            this.ComboBox_BlockNum.Size = new System.Drawing.Size(87, 20);
            this.ComboBox_BlockNum.TabIndex = 3;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(9, 61);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(83, 24);
            this.label30.TabIndex = 2;
            this.label30.Text = "访问密码：\r\n(8个16进制数)";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(9, 37);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(89, 12);
            this.label29.TabIndex = 1;
            this.label29.Text = "数据块字地址：";
            // 
            // ComboBox_EPC6
            // 
            this.ComboBox_EPC6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_EPC6.FormattingEnabled = true;
            this.ComboBox_EPC6.Location = new System.Drawing.Point(6, 15);
            this.ComboBox_EPC6.Name = "ComboBox_EPC6";
            this.ComboBox_EPC6.Size = new System.Drawing.Size(313, 20);
            this.ComboBox_EPC6.TabIndex = 0;
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.Label_Alarm);
            this.groupBox16.Controls.Add(this.button4);
            this.groupBox16.Controls.Add(this.Button_SetEASAlarm_G2);
            this.groupBox16.Controls.Add(this.groupBox17);
            this.groupBox16.Controls.Add(this.Edit_AccessCode5);
            this.groupBox16.Controls.Add(this.label28);
            this.groupBox16.Controls.Add(this.ComboBox_EPC5);
            this.groupBox16.Location = new System.Drawing.Point(485, 420);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(325, 109);
            this.groupBox16.TabIndex = 7;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "EAS报警";
            // 
            // Label_Alarm
            // 
            this.Label_Alarm.AutoSize = true;
            this.Label_Alarm.Font = new System.Drawing.Font("MS Reference Sans Serif", 30.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)), true);
            this.Label_Alarm.ForeColor = System.Drawing.Color.Red;
            this.Label_Alarm.Location = new System.Drawing.Point(243, 36);
            this.Label_Alarm.Name = "Label_Alarm";
            this.Label_Alarm.Size = new System.Drawing.Size(51, 46);
            this.Label_Alarm.TabIndex = 14;
            this.Label_Alarm.Text = "l";
            // 
            // button4
            // 
            this.button4.Enabled = false;
            this.button4.Location = new System.Drawing.Point(226, 81);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(89, 23);
            this.button4.TabIndex = 13;
            this.button4.Text = "检测报警";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // Button_SetEASAlarm_G2
            // 
            this.Button_SetEASAlarm_G2.Location = new System.Drawing.Point(110, 81);
            this.Button_SetEASAlarm_G2.Name = "Button_SetEASAlarm_G2";
            this.Button_SetEASAlarm_G2.Size = new System.Drawing.Size(97, 23);
            this.Button_SetEASAlarm_G2.TabIndex = 12;
            this.Button_SetEASAlarm_G2.Text = "报警设置";
            this.Button_SetEASAlarm_G2.UseVisualStyleBackColor = true;
            this.Button_SetEASAlarm_G2.Click += new System.EventHandler(this.Button_SetEASAlarm_G2_Click);
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.NoAlarm_G2);
            this.groupBox17.Controls.Add(this.Alarm_G2);
            this.groupBox17.Location = new System.Drawing.Point(6, 59);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(100, 47);
            this.groupBox17.TabIndex = 11;
            this.groupBox17.TabStop = false;
            // 
            // NoAlarm_G2
            // 
            this.NoAlarm_G2.AutoSize = true;
            this.NoAlarm_G2.Location = new System.Drawing.Point(5, 27);
            this.NoAlarm_G2.Name = "NoAlarm_G2";
            this.NoAlarm_G2.Size = new System.Drawing.Size(59, 16);
            this.NoAlarm_G2.TabIndex = 1;
            this.NoAlarm_G2.TabStop = true;
            this.NoAlarm_G2.Text = "不报警";
            this.NoAlarm_G2.UseVisualStyleBackColor = true;
            // 
            // Alarm_G2
            // 
            this.Alarm_G2.AutoSize = true;
            this.Alarm_G2.Location = new System.Drawing.Point(5, 10);
            this.Alarm_G2.Name = "Alarm_G2";
            this.Alarm_G2.Size = new System.Drawing.Size(47, 16);
            this.Alarm_G2.TabIndex = 0;
            this.Alarm_G2.TabStop = true;
            this.Alarm_G2.Text = "报警";
            this.Alarm_G2.UseVisualStyleBackColor = true;
            // 
            // Edit_AccessCode5
            // 
            this.Edit_AccessCode5.Location = new System.Drawing.Point(107, 38);
            this.Edit_AccessCode5.MaxLength = 8;
            this.Edit_AccessCode5.Name = "Edit_AccessCode5";
            this.Edit_AccessCode5.Size = new System.Drawing.Size(100, 21);
            this.Edit_AccessCode5.TabIndex = 10;
            this.Edit_AccessCode5.Text = "00000000";
            this.Edit_AccessCode5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(6, 35);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(83, 24);
            this.label28.TabIndex = 9;
            this.label28.Text = "访问密码：\r\n(8个16进制数)";
            // 
            // ComboBox_EPC5
            // 
            this.ComboBox_EPC5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_EPC5.FormattingEnabled = true;
            this.ComboBox_EPC5.Location = new System.Drawing.Point(6, 13);
            this.ComboBox_EPC5.Name = "ComboBox_EPC5";
            this.ComboBox_EPC5.Size = new System.Drawing.Size(313, 20);
            this.ComboBox_EPC5.TabIndex = 8;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.Button_CheckReadProtected_G2);
            this.groupBox15.Controls.Add(this.Button_RemoveReadProtect_G2);
            this.groupBox15.Controls.Add(this.Button_SetMultiReadProtect_G2);
            this.groupBox15.Controls.Add(this.Button_SetReadProtect_G2);
            this.groupBox15.Controls.Add(this.Edit_AccessCode4);
            this.groupBox15.Controls.Add(this.label27);
            this.groupBox15.Controls.Add(this.ComboBox_EPC4);
            this.groupBox15.Location = new System.Drawing.Point(485, 247);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(325, 171);
            this.groupBox15.TabIndex = 6;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "读保护";
            // 
            // Button_CheckReadProtected_G2
            // 
            this.Button_CheckReadProtected_G2.Enabled = false;
            this.Button_CheckReadProtected_G2.Location = new System.Drawing.Point(6, 143);
            this.Button_CheckReadProtected_G2.Name = "Button_CheckReadProtected_G2";
            this.Button_CheckReadProtected_G2.Size = new System.Drawing.Size(313, 23);
            this.Button_CheckReadProtected_G2.TabIndex = 6;
            this.Button_CheckReadProtected_G2.Text = "检测单张被读保护（不需要访问密码）       ";
            this.Button_CheckReadProtected_G2.UseVisualStyleBackColor = true;
            this.Button_CheckReadProtected_G2.Click += new System.EventHandler(this.Button_CheckReadProtected_G2_Click);
            // 
            // Button_RemoveReadProtect_G2
            // 
            this.Button_RemoveReadProtect_G2.Enabled = false;
            this.Button_RemoveReadProtect_G2.Location = new System.Drawing.Point(6, 116);
            this.Button_RemoveReadProtect_G2.Name = "Button_RemoveReadProtect_G2";
            this.Button_RemoveReadProtect_G2.Size = new System.Drawing.Size(313, 23);
            this.Button_RemoveReadProtect_G2.TabIndex = 5;
            this.Button_RemoveReadProtect_G2.Text = "解除单张读保护（不需EPC号）";
            this.Button_RemoveReadProtect_G2.UseVisualStyleBackColor = true;
            this.Button_RemoveReadProtect_G2.Click += new System.EventHandler(this.Button_RemoveReadProtect_G2_Click);
            // 
            // Button_SetMultiReadProtect_G2
            // 
            this.Button_SetMultiReadProtect_G2.Enabled = false;
            this.Button_SetMultiReadProtect_G2.Location = new System.Drawing.Point(6, 89);
            this.Button_SetMultiReadProtect_G2.Name = "Button_SetMultiReadProtect_G2";
            this.Button_SetMultiReadProtect_G2.Size = new System.Drawing.Size(313, 23);
            this.Button_SetMultiReadProtect_G2.TabIndex = 4;
            this.Button_SetMultiReadProtect_G2.Text = "设置单张读保护（不需EPC号）";
            this.Button_SetMultiReadProtect_G2.UseVisualStyleBackColor = true;
            this.Button_SetMultiReadProtect_G2.Click += new System.EventHandler(this.Button_SetMultiReadProtect_G2_Click);
            // 
            // Button_SetReadProtect_G2
            // 
            this.Button_SetReadProtect_G2.Enabled = false;
            this.Button_SetReadProtect_G2.Location = new System.Drawing.Point(6, 62);
            this.Button_SetReadProtect_G2.Name = "Button_SetReadProtect_G2";
            this.Button_SetReadProtect_G2.Size = new System.Drawing.Size(313, 23);
            this.Button_SetReadProtect_G2.TabIndex = 3;
            this.Button_SetReadProtect_G2.Text = "设置单张读保护";
            this.Button_SetReadProtect_G2.UseVisualStyleBackColor = true;
            this.Button_SetReadProtect_G2.Click += new System.EventHandler(this.Button_SetReadProtect_G2_Click);
            // 
            // Edit_AccessCode4
            // 
            this.Edit_AccessCode4.Location = new System.Drawing.Point(107, 38);
            this.Edit_AccessCode4.MaxLength = 8;
            this.Edit_AccessCode4.Name = "Edit_AccessCode4";
            this.Edit_AccessCode4.Size = new System.Drawing.Size(100, 21);
            this.Edit_AccessCode4.TabIndex = 2;
            this.Edit_AccessCode4.Text = "00000000";
            this.Edit_AccessCode4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(6, 35);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(83, 24);
            this.label27.TabIndex = 1;
            this.label27.Text = "访问密码：\r\n(8个16进制数)";
            // 
            // ComboBox_EPC4
            // 
            this.ComboBox_EPC4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_EPC4.FormattingEnabled = true;
            this.ComboBox_EPC4.Location = new System.Drawing.Point(8, 13);
            this.ComboBox_EPC4.Name = "ComboBox_EPC4";
            this.ComboBox_EPC4.Size = new System.Drawing.Size(311, 20);
            this.ComboBox_EPC4.TabIndex = 0;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.Button_WriteEPC_G2);
            this.groupBox14.Controls.Add(this.Edit_AccessCode3);
            this.groupBox14.Controls.Add(this.label26);
            this.groupBox14.Controls.Add(this.Edit_WriteEPC);
            this.groupBox14.Controls.Add(this.label25);
            this.groupBox14.Location = new System.Drawing.Point(485, 171);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(325, 74);
            this.groupBox14.TabIndex = 5;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "写EPC号（只改写天线范围内某一张标签）";
            // 
            // Button_WriteEPC_G2
            // 
            this.Button_WriteEPC_G2.Enabled = false;
            this.Button_WriteEPC_G2.Location = new System.Drawing.Point(244, 46);
            this.Button_WriteEPC_G2.Name = "Button_WriteEPC_G2";
            this.Button_WriteEPC_G2.Size = new System.Drawing.Size(75, 23);
            this.Button_WriteEPC_G2.TabIndex = 4;
            this.Button_WriteEPC_G2.Text = "写EPC";
            this.Button_WriteEPC_G2.UseVisualStyleBackColor = true;
            this.Button_WriteEPC_G2.Click += new System.EventHandler(this.Button_WriteEPC_G2_Click);
            // 
            // Edit_AccessCode3
            // 
            this.Edit_AccessCode3.Location = new System.Drawing.Point(107, 48);
            this.Edit_AccessCode3.MaxLength = 8;
            this.Edit_AccessCode3.Name = "Edit_AccessCode3";
            this.Edit_AccessCode3.Size = new System.Drawing.Size(100, 21);
            this.Edit_AccessCode3.TabIndex = 3;
            this.Edit_AccessCode3.Text = "00000000";
            this.Edit_AccessCode3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(6, 43);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(83, 24);
            this.label26.TabIndex = 2;
            this.label26.Text = "访问密码：\r\n(8个16进制数)";
            // 
            // Edit_WriteEPC
            // 
            this.Edit_WriteEPC.Location = new System.Drawing.Point(77, 18);
            this.Edit_WriteEPC.MaxLength = 60;
            this.Edit_WriteEPC.Name = "Edit_WriteEPC";
            this.Edit_WriteEPC.Size = new System.Drawing.Size(242, 21);
            this.Edit_WriteEPC.TabIndex = 1;
            this.Edit_WriteEPC.Text = "0000";
            this.Edit_WriteEPC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(6, 15);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(53, 24);
            this.label25.TabIndex = 0;
            this.label25.Text = "写EPC号:\r\n(1-15字)";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.Button_DestroyCard);
            this.groupBox13.Controls.Add(this.Edit_DestroyCode);
            this.groupBox13.Controls.Add(this.label24);
            this.groupBox13.Controls.Add(this.ComboBox_EPC3);
            this.groupBox13.Location = new System.Drawing.Point(485, 100);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(325, 68);
            this.groupBox13.TabIndex = 4;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "销毁标签";
            // 
            // Button_DestroyCard
            // 
            this.Button_DestroyCard.Location = new System.Drawing.Point(244, 39);
            this.Button_DestroyCard.Name = "Button_DestroyCard";
            this.Button_DestroyCard.Size = new System.Drawing.Size(75, 23);
            this.Button_DestroyCard.TabIndex = 3;
            this.Button_DestroyCard.Text = "销毁";
            this.Button_DestroyCard.UseVisualStyleBackColor = true;
            this.Button_DestroyCard.Click += new System.EventHandler(this.Button_DestroyCard_Click);
            // 
            // Edit_DestroyCode
            // 
            this.Edit_DestroyCode.Location = new System.Drawing.Point(115, 41);
            this.Edit_DestroyCode.MaxLength = 8;
            this.Edit_DestroyCode.Name = "Edit_DestroyCode";
            this.Edit_DestroyCode.Size = new System.Drawing.Size(92, 21);
            this.Edit_DestroyCode.TabIndex = 2;
            this.Edit_DestroyCode.Text = "00000000";
            this.Edit_DestroyCode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(6, 39);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(83, 24);
            this.label24.TabIndex = 1;
            this.label24.Text = "销毁密码：\r\n(8个16进制数)";
            // 
            // ComboBox_EPC3
            // 
            this.ComboBox_EPC3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_EPC3.FormattingEnabled = true;
            this.ComboBox_EPC3.Location = new System.Drawing.Point(8, 16);
            this.ComboBox_EPC3.Name = "ComboBox_EPC3";
            this.ComboBox_EPC3.Size = new System.Drawing.Size(311, 20);
            this.ComboBox_EPC3.TabIndex = 0;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.CheckBox_TID);
            this.groupBox12.Controls.Add(this.groupBox33);
            this.groupBox12.Controls.Add(this.button2);
            this.groupBox12.Controls.Add(this.ComboBox_IntervalTime);
            this.groupBox12.Controls.Add(this.label23);
            this.groupBox12.Location = new System.Drawing.Point(485, 0);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(325, 97);
            this.groupBox12.TabIndex = 3;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "询查标签";
            // 
            // CheckBox_TID
            // 
            this.CheckBox_TID.AutoSize = true;
            this.CheckBox_TID.Location = new System.Drawing.Point(230, 62);
            this.CheckBox_TID.Name = "CheckBox_TID";
            this.CheckBox_TID.Size = new System.Drawing.Size(66, 16);
            this.CheckBox_TID.TabIndex = 8;
            this.CheckBox_TID.Text = "TID询查";
            this.CheckBox_TID.UseVisualStyleBackColor = true;
            this.CheckBox_TID.CheckedChanged += new System.EventHandler(this.CheckBox_TID_CheckedChanged);
            // 
            // groupBox33
            // 
            this.groupBox33.Controls.Add(this.textBox5);
            this.groupBox33.Controls.Add(this.label55);
            this.groupBox33.Controls.Add(this.textBox4);
            this.groupBox33.Controls.Add(this.label54);
            this.groupBox33.Location = new System.Drawing.Point(8, 42);
            this.groupBox33.Name = "groupBox33";
            this.groupBox33.Size = new System.Drawing.Size(209, 48);
            this.groupBox33.TabIndex = 7;
            this.groupBox33.TabStop = false;
            this.groupBox33.Text = "TID询查条件";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(167, 14);
            this.textBox5.MaxLength = 2;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(37, 21);
            this.textBox5.TabIndex = 3;
            this.textBox5.Text = "04";
            this.textBox5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(107, 24);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(65, 12);
            this.label55.TabIndex = 2;
            this.label55.Text = "数据字数：";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(64, 14);
            this.textBox4.MaxLength = 2;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(37, 21);
            this.textBox4.TabIndex = 1;
            this.textBox4.Text = "02";
            this.textBox4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(4, 24);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(65, 12);
            this.label54.TabIndex = 0;
            this.label54.Text = "起始地址：";
            // 
            // button2
            // 
            this.button2.Enabled = false;
            this.button2.Location = new System.Drawing.Point(230, 17);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(89, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "查询标签";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // ComboBox_IntervalTime
            // 
            this.ComboBox_IntervalTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_IntervalTime.FormattingEnabled = true;
            this.ComboBox_IntervalTime.Location = new System.Drawing.Point(117, 20);
            this.ComboBox_IntervalTime.Name = "ComboBox_IntervalTime";
            this.ComboBox_IntervalTime.Size = new System.Drawing.Size(98, 20);
            this.ComboBox_IntervalTime.TabIndex = 1;
            this.ComboBox_IntervalTime.SelectedIndexChanged += new System.EventHandler(this.ComboBox_IntervalTime_SelectedIndexChanged);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(6, 24);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(113, 12);
            this.label23.TabIndex = 0;
            this.label23.Text = "询查标签间隔时间：";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.Button_SetProtectState);
            this.groupBox7.Controls.Add(this.textBox2);
            this.groupBox7.Controls.Add(this.label22);
            this.groupBox7.Controls.Add(this.groupBox11);
            this.groupBox7.Controls.Add(this.groupBox10);
            this.groupBox7.Controls.Add(this.groupBox8);
            this.groupBox7.Controls.Add(this.ComboBox_EPC1);
            this.groupBox7.Location = new System.Drawing.Point(1, 414);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(481, 209);
            this.groupBox7.TabIndex = 2;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "设置读写保护状态";
            // 
            // Button_SetProtectState
            // 
            this.Button_SetProtectState.Location = new System.Drawing.Point(375, 181);
            this.Button_SetProtectState.Name = "Button_SetProtectState";
            this.Button_SetProtectState.Size = new System.Drawing.Size(99, 23);
            this.Button_SetProtectState.TabIndex = 6;
            this.Button_SetProtectState.Text = "设置保护";
            this.Button_SetProtectState.UseVisualStyleBackColor = true;
            this.Button_SetProtectState.Click += new System.EventHandler(this.Button_SetProtectState_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(263, 183);
            this.textBox2.MaxLength = 8;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 21);
            this.textBox2.TabIndex = 5;
            this.textBox2.Text = "00000000";
            this.textBox2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(261, 165);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(143, 12);
            this.label22.TabIndex = 4;
            this.label22.Text = "访问密码：(8个16进制数)";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.AlwaysNot2);
            this.groupBox11.Controls.Add(this.Always2);
            this.groupBox11.Controls.Add(this.Proect2);
            this.groupBox11.Controls.Add(this.NoProect2);
            this.groupBox11.Location = new System.Drawing.Point(258, 43);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(217, 120);
            this.groupBox11.TabIndex = 3;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "EPC-TID-用户区的写保护类型";
            // 
            // AlwaysNot2
            // 
            this.AlwaysNot2.AutoSize = true;
            this.AlwaysNot2.Location = new System.Drawing.Point(5, 97);
            this.AlwaysNot2.Name = "AlwaysNot2";
            this.AlwaysNot2.Size = new System.Drawing.Size(83, 16);
            this.AlwaysNot2.TabIndex = 3;
            this.AlwaysNot2.TabStop = true;
            this.AlwaysNot2.Text = "永远不可写";
            this.AlwaysNot2.UseVisualStyleBackColor = true;
            // 
            // Always2
            // 
            this.Always2.AutoSize = true;
            this.Always2.Location = new System.Drawing.Point(5, 71);
            this.Always2.Name = "Always2";
            this.Always2.Size = new System.Drawing.Size(71, 16);
            this.Always2.TabIndex = 2;
            this.Always2.TabStop = true;
            this.Always2.Text = "永远可写";
            this.Always2.UseVisualStyleBackColor = true;
            // 
            // Proect2
            // 
            this.Proect2.AutoSize = true;
            this.Proect2.Location = new System.Drawing.Point(5, 45);
            this.Proect2.Name = "Proect2";
            this.Proect2.Size = new System.Drawing.Size(119, 16);
            this.Proect2.TabIndex = 1;
            this.Proect2.TabStop = true;
            this.Proect2.Text = "密码保护下的可写";
            this.Proect2.UseVisualStyleBackColor = true;
            // 
            // NoProect2
            // 
            this.NoProect2.AutoSize = true;
            this.NoProect2.Location = new System.Drawing.Point(5, 19);
            this.NoProect2.Name = "NoProect2";
            this.NoProect2.Size = new System.Drawing.Size(107, 16);
            this.NoProect2.TabIndex = 0;
            this.NoProect2.TabStop = true;
            this.NoProect2.Text = "无保护下的可写";
            this.NoProect2.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.P_User);
            this.groupBox10.Controls.Add(this.P_TID);
            this.groupBox10.Controls.Add(this.P_EPC);
            this.groupBox10.Controls.Add(this.P_Reserve);
            this.groupBox10.Location = new System.Drawing.Point(259, 12);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(215, 31);
            this.groupBox10.TabIndex = 2;
            this.groupBox10.TabStop = false;
            // 
            // P_User
            // 
            this.P_User.AutoSize = true;
            this.P_User.Location = new System.Drawing.Point(156, 11);
            this.P_User.Name = "P_User";
            this.P_User.Size = new System.Drawing.Size(59, 16);
            this.P_User.TabIndex = 3;
            this.P_User.TabStop = true;
            this.P_User.Text = "用户区";
            this.P_User.UseVisualStyleBackColor = true;
            this.P_User.CheckedChanged += new System.EventHandler(this.P_User_CheckedChanged);
            // 
            // P_TID
            // 
            this.P_TID.AutoSize = true;
            this.P_TID.Location = new System.Drawing.Point(109, 11);
            this.P_TID.Name = "P_TID";
            this.P_TID.Size = new System.Drawing.Size(53, 16);
            this.P_TID.TabIndex = 2;
            this.P_TID.TabStop = true;
            this.P_TID.Text = "TID区";
            this.P_TID.UseVisualStyleBackColor = true;
            this.P_TID.CheckedChanged += new System.EventHandler(this.P_TID_CheckedChanged);
            // 
            // P_EPC
            // 
            this.P_EPC.AutoSize = true;
            this.P_EPC.Location = new System.Drawing.Point(59, 11);
            this.P_EPC.Name = "P_EPC";
            this.P_EPC.Size = new System.Drawing.Size(53, 16);
            this.P_EPC.TabIndex = 1;
            this.P_EPC.TabStop = true;
            this.P_EPC.Text = "EPC区";
            this.P_EPC.UseVisualStyleBackColor = true;
            this.P_EPC.CheckedChanged += new System.EventHandler(this.P_EPC_CheckedChanged);
            // 
            // P_Reserve
            // 
            this.P_Reserve.AutoSize = true;
            this.P_Reserve.Location = new System.Drawing.Point(4, 11);
            this.P_Reserve.Name = "P_Reserve";
            this.P_Reserve.Size = new System.Drawing.Size(59, 16);
            this.P_Reserve.TabIndex = 0;
            this.P_Reserve.TabStop = true;
            this.P_Reserve.Text = "保留区";
            this.P_Reserve.UseVisualStyleBackColor = true;
            this.P_Reserve.CheckedChanged += new System.EventHandler(this.P_Reserve_CheckedChanged);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.AlwaysNot);
            this.groupBox8.Controls.Add(this.Always);
            this.groupBox8.Controls.Add(this.Proect);
            this.groupBox8.Controls.Add(this.NoProect);
            this.groupBox8.Controls.Add(this.groupBox9);
            this.groupBox8.Location = new System.Drawing.Point(4, 35);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(248, 171);
            this.groupBox8.TabIndex = 1;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "密码区的读写保护类型";
            // 
            // AlwaysNot
            // 
            this.AlwaysNot.AutoSize = true;
            this.AlwaysNot.Location = new System.Drawing.Point(6, 149);
            this.AlwaysNot.Name = "AlwaysNot";
            this.AlwaysNot.Size = new System.Drawing.Size(119, 16);
            this.AlwaysNot.TabIndex = 4;
            this.AlwaysNot.TabStop = true;
            this.AlwaysNot.Text = "永远不能读不能写";
            this.AlwaysNot.UseVisualStyleBackColor = true;
            // 
            // Always
            // 
            this.Always.AutoSize = true;
            this.Always.Location = new System.Drawing.Point(6, 125);
            this.Always.Name = "Always";
            this.Always.Size = new System.Drawing.Size(95, 16);
            this.Always.TabIndex = 3;
            this.Always.TabStop = true;
            this.Always.Text = "永远可读可写";
            this.Always.UseVisualStyleBackColor = true;
            // 
            // Proect
            // 
            this.Proect.AutoSize = true;
            this.Proect.Location = new System.Drawing.Point(6, 92);
            this.Proect.Name = "Proect";
            this.Proect.Size = new System.Drawing.Size(143, 16);
            this.Proect.TabIndex = 2;
            this.Proect.TabStop = true;
            this.Proect.Text = "密码保护下的可读可写";
            this.Proect.UseVisualStyleBackColor = true;
            // 
            // NoProect
            // 
            this.NoProect.AutoSize = true;
            this.NoProect.Location = new System.Drawing.Point(6, 67);
            this.NoProect.Name = "NoProect";
            this.NoProect.Size = new System.Drawing.Size(131, 16);
            this.NoProect.TabIndex = 1;
            this.NoProect.TabStop = true;
            this.NoProect.Text = "无保护下的可读可写";
            this.NoProect.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.AccessCode);
            this.groupBox9.Controls.Add(this.DestroyCode);
            this.groupBox9.Location = new System.Drawing.Point(5, 18);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(237, 48);
            this.groupBox9.TabIndex = 0;
            this.groupBox9.TabStop = false;
            // 
            // AccessCode
            // 
            this.AccessCode.AutoSize = true;
            this.AccessCode.Location = new System.Drawing.Point(108, 20);
            this.AccessCode.Name = "AccessCode";
            this.AccessCode.Size = new System.Drawing.Size(71, 16);
            this.AccessCode.TabIndex = 1;
            this.AccessCode.TabStop = true;
            this.AccessCode.Text = "访问密码";
            this.AccessCode.UseVisualStyleBackColor = true;
            // 
            // DestroyCode
            // 
            this.DestroyCode.AutoSize = true;
            this.DestroyCode.Location = new System.Drawing.Point(6, 20);
            this.DestroyCode.Name = "DestroyCode";
            this.DestroyCode.Size = new System.Drawing.Size(71, 16);
            this.DestroyCode.TabIndex = 0;
            this.DestroyCode.TabStop = true;
            this.DestroyCode.Text = "销毁密码";
            this.DestroyCode.UseVisualStyleBackColor = true;
            // 
            // ComboBox_EPC1
            // 
            this.ComboBox_EPC1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_EPC1.FormattingEnabled = true;
            this.ComboBox_EPC1.Location = new System.Drawing.Point(4, 14);
            this.ComboBox_EPC1.Name = "ComboBox_EPC1";
            this.ComboBox_EPC1.Size = new System.Drawing.Size(249, 20);
            this.ComboBox_EPC1.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.textBox_pc);
            this.groupBox5.Controls.Add(this.checkBox_pc);
            this.groupBox5.Controls.Add(this.BlockWrite);
            this.groupBox5.Controls.Add(this.ComboBox_EPC2);
            this.groupBox5.Controls.Add(this.button7);
            this.groupBox5.Controls.Add(this.Button_BlockErase);
            this.groupBox5.Controls.Add(this.Button_DataWrite);
            this.groupBox5.Controls.Add(this.SpeedButton_Read_G2);
            this.groupBox5.Controls.Add(this.Edit_WriteData);
            this.groupBox5.Controls.Add(this.Edit_AccessCode2);
            this.groupBox5.Controls.Add(this.textBox1);
            this.groupBox5.Controls.Add(this.Edit_WordPtr);
            this.groupBox5.Controls.Add(this.listBox1);
            this.groupBox5.Controls.Add(this.label21);
            this.groupBox5.Controls.Add(this.label20);
            this.groupBox5.Controls.Add(this.label19);
            this.groupBox5.Controls.Add(this.label18);
            this.groupBox5.Controls.Add(this.groupBox6);
            this.groupBox5.Location = new System.Drawing.Point(1, 211);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(481, 203);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "读数据/写数据/块擦除";
            // 
            // textBox_pc
            // 
            this.textBox_pc.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.textBox_pc.Location = new System.Drawing.Point(403, 12);
            this.textBox_pc.Name = "textBox_pc";
            this.textBox_pc.ReadOnly = true;
            this.textBox_pc.Size = new System.Drawing.Size(71, 21);
            this.textBox_pc.TabIndex = 23;
            this.textBox_pc.Text = "0800";
            // 
            // checkBox_pc
            // 
            this.checkBox_pc.AutoSize = true;
            this.checkBox_pc.Location = new System.Drawing.Point(277, 17);
            this.checkBox_pc.Name = "checkBox_pc";
            this.checkBox_pc.Size = new System.Drawing.Size(120, 16);
            this.checkBox_pc.TabIndex = 22;
            this.checkBox_pc.Text = "自动计算并添加PC";
            this.checkBox_pc.UseVisualStyleBackColor = true;
            this.checkBox_pc.CheckedChanged += new System.EventHandler(this.checkBox_pc_CheckedChanged);
            // 
            // BlockWrite
            // 
            this.BlockWrite.Location = new System.Drawing.Point(92, 175);
            this.BlockWrite.Name = "BlockWrite";
            this.BlockWrite.Size = new System.Drawing.Size(57, 23);
            this.BlockWrite.TabIndex = 17;
            this.BlockWrite.Text = "块写";
            this.BlockWrite.UseVisualStyleBackColor = true;
            this.BlockWrite.Click += new System.EventHandler(this.BlockWrite_Click);
            // 
            // ComboBox_EPC2
            // 
            this.ComboBox_EPC2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_EPC2.FormattingEnabled = true;
            this.ComboBox_EPC2.Location = new System.Drawing.Point(4, 16);
            this.ComboBox_EPC2.Name = "ComboBox_EPC2";
            this.ComboBox_EPC2.Size = new System.Drawing.Size(267, 20);
            this.ComboBox_EPC2.TabIndex = 15;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(215, 175);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(56, 23);
            this.button7.TabIndex = 14;
            this.button7.Text = "清除";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // Button_BlockErase
            // 
            this.Button_BlockErase.Location = new System.Drawing.Point(153, 175);
            this.Button_BlockErase.Name = "Button_BlockErase";
            this.Button_BlockErase.Size = new System.Drawing.Size(58, 23);
            this.Button_BlockErase.TabIndex = 13;
            this.Button_BlockErase.Text = "块擦除";
            this.Button_BlockErase.UseVisualStyleBackColor = true;
            this.Button_BlockErase.Click += new System.EventHandler(this.Button_BlockErase_Click);
            // 
            // Button_DataWrite
            // 
            this.Button_DataWrite.Location = new System.Drawing.Point(46, 175);
            this.Button_DataWrite.Name = "Button_DataWrite";
            this.Button_DataWrite.Size = new System.Drawing.Size(40, 23);
            this.Button_DataWrite.TabIndex = 12;
            this.Button_DataWrite.Text = "写";
            this.Button_DataWrite.UseVisualStyleBackColor = true;
            this.Button_DataWrite.Click += new System.EventHandler(this.Button_DataWrite_Click);
            // 
            // SpeedButton_Read_G2
            // 
            this.SpeedButton_Read_G2.Location = new System.Drawing.Point(4, 175);
            this.SpeedButton_Read_G2.Name = "SpeedButton_Read_G2";
            this.SpeedButton_Read_G2.Size = new System.Drawing.Size(38, 23);
            this.SpeedButton_Read_G2.TabIndex = 11;
            this.SpeedButton_Read_G2.Text = "读";
            this.SpeedButton_Read_G2.UseVisualStyleBackColor = true;
            this.SpeedButton_Read_G2.Click += new System.EventHandler(this.SpeedButton_Read_G2_Click);
            // 
            // Edit_WriteData
            // 
            this.Edit_WriteData.Location = new System.Drawing.Point(116, 152);
            this.Edit_WriteData.Name = "Edit_WriteData";
            this.Edit_WriteData.Size = new System.Drawing.Size(155, 21);
            this.Edit_WriteData.TabIndex = 10;
            this.Edit_WriteData.Text = "0000";
            this.Edit_WriteData.TextChanged += new System.EventHandler(this.Edit_WriteData_TextChanged);
            this.Edit_WriteData.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // Edit_AccessCode2
            // 
            this.Edit_AccessCode2.Location = new System.Drawing.Point(155, 126);
            this.Edit_AccessCode2.MaxLength = 8;
            this.Edit_AccessCode2.Name = "Edit_AccessCode2";
            this.Edit_AccessCode2.Size = new System.Drawing.Size(116, 21);
            this.Edit_AccessCode2.TabIndex = 9;
            this.Edit_AccessCode2.Text = "00000000";
            this.Edit_AccessCode2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(205, 99);
            this.textBox1.MaxLength = 3;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(66, 21);
            this.textBox1.TabIndex = 8;
            this.textBox1.Text = "4";
            this.textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_Len_6B_KeyPress);
            // 
            // Edit_WordPtr
            // 
            this.Edit_WordPtr.Location = new System.Drawing.Point(205, 68);
            this.Edit_WordPtr.MaxLength = 2;
            this.Edit_WordPtr.Name = "Edit_WordPtr";
            this.Edit_WordPtr.Size = new System.Drawing.Size(66, 21);
            this.Edit_WordPtr.TabIndex = 7;
            this.Edit_WordPtr.Text = "00";
            this.Edit_WordPtr.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(277, 38);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(198, 160);
            this.listBox1.TabIndex = 6;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(8, 157);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(101, 12);
            this.label21.TabIndex = 5;
            this.label21.Text = "写数据：(16进制)";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(8, 129);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(143, 12);
            this.label20.TabIndex = 4;
            this.label20.Text = "访问密码：(8个16进制数)";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(1, 102);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(209, 12);
            this.label19.TabIndex = 3;
            this.label19.Text = "读/块擦除长度：(0-120/字/10进制数)";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(8, 77);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(137, 12);
            this.label18.TabIndex = 2;
            this.label18.Text = "起始地址:(字/16进制数)";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.C_User);
            this.groupBox6.Controls.Add(this.C_TID);
            this.groupBox6.Controls.Add(this.C_EPC);
            this.groupBox6.Controls.Add(this.C_Reserve);
            this.groupBox6.Location = new System.Drawing.Point(6, 31);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(265, 31);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            // 
            // C_User
            // 
            this.C_User.AutoSize = true;
            this.C_User.Location = new System.Drawing.Point(207, 11);
            this.C_User.Name = "C_User";
            this.C_User.Size = new System.Drawing.Size(59, 16);
            this.C_User.TabIndex = 3;
            this.C_User.TabStop = true;
            this.C_User.Text = "用户区";
            this.C_User.UseVisualStyleBackColor = true;
            this.C_User.CheckedChanged += new System.EventHandler(this.C_User_CheckedChanged);
            // 
            // C_TID
            // 
            this.C_TID.AutoSize = true;
            this.C_TID.Location = new System.Drawing.Point(149, 11);
            this.C_TID.Name = "C_TID";
            this.C_TID.Size = new System.Drawing.Size(53, 16);
            this.C_TID.TabIndex = 2;
            this.C_TID.TabStop = true;
            this.C_TID.Text = "TID区";
            this.C_TID.UseVisualStyleBackColor = true;
            this.C_TID.CheckedChanged += new System.EventHandler(this.C_TID_CheckedChanged);
            // 
            // C_EPC
            // 
            this.C_EPC.AutoSize = true;
            this.C_EPC.Location = new System.Drawing.Point(90, 11);
            this.C_EPC.Name = "C_EPC";
            this.C_EPC.Size = new System.Drawing.Size(53, 16);
            this.C_EPC.TabIndex = 1;
            this.C_EPC.TabStop = true;
            this.C_EPC.Text = "EPC区";
            this.C_EPC.UseVisualStyleBackColor = true;
            this.C_EPC.CheckedChanged += new System.EventHandler(this.C_EPC_CheckedChanged);
            // 
            // C_Reserve
            // 
            this.C_Reserve.AutoSize = true;
            this.C_Reserve.Location = new System.Drawing.Point(4, 11);
            this.C_Reserve.Name = "C_Reserve";
            this.C_Reserve.Size = new System.Drawing.Size(59, 16);
            this.C_Reserve.TabIndex = 0;
            this.C_Reserve.TabStop = true;
            this.C_Reserve.Text = "保留区";
            this.C_Reserve.UseVisualStyleBackColor = true;
            this.C_Reserve.CheckedChanged += new System.EventHandler(this.C_Reserve_CheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.ListView1_EPC);
            this.groupBox4.Location = new System.Drawing.Point(1, 0);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(480, 162);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "标签显示";
            // 
            // ListView1_EPC
            // 
            this.ListView1_EPC.AccessibleRole = System.Windows.Forms.AccessibleRole.IpAddress;
            this.ListView1_EPC.AutoArrange = false;
            this.ListView1_EPC.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ListView1_EPC.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.listViewCol_Number,
            this.listViewCol_ID,
            this.listViewCol_Length,
            this.listViewCol_Times});
            this.ListView1_EPC.Dock = System.Windows.Forms.DockStyle.Top;
            this.ListView1_EPC.FullRowSelect = true;
            this.ListView1_EPC.GridLines = true;
            this.ListView1_EPC.Location = new System.Drawing.Point(3, 17);
            this.ListView1_EPC.Name = "ListView1_EPC";
            this.ListView1_EPC.Size = new System.Drawing.Size(474, 138);
            this.ListView1_EPC.TabIndex = 1;
            this.ListView1_EPC.UseCompatibleStateImageBehavior = false;
            this.ListView1_EPC.View = System.Windows.Forms.View.Details;
            // 
            // listViewCol_Number
            // 
            this.listViewCol_Number.Text = "序号";
            this.listViewCol_Number.Width = 40;
            // 
            // listViewCol_ID
            // 
            this.listViewCol_ID.Text = "EPC号";
            this.listViewCol_ID.Width = 150;
            // 
            // listViewCol_Length
            // 
            this.listViewCol_Length.Text = "EPC长度";
            this.listViewCol_Length.Width = 150;
            // 
            // listViewCol_Times
            // 
            this.listViewCol_Times.Text = "次数";
            // 
            // TabSheet_6B
            // 
            this.TabSheet_6B.Controls.Add(this.groupBox22);
            this.TabSheet_6B.Controls.Add(this.groupBox21);
            this.TabSheet_6B.Controls.Add(this.groupBox20);
            this.TabSheet_6B.Controls.Add(this.groupBox19);
            this.TabSheet_6B.Location = new System.Drawing.Point(4, 21);
            this.TabSheet_6B.Name = "TabSheet_6B";
            this.TabSheet_6B.Size = new System.Drawing.Size(817, 625);
            this.TabSheet_6B.TabIndex = 3;
            this.TabSheet_6B.Text = "18000-6B Test";
            this.TabSheet_6B.UseVisualStyleBackColor = true;
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.Edit_WriteData_6B);
            this.groupBox22.Controls.Add(this.label36);
            this.groupBox22.Controls.Add(this.listBox2);
            this.groupBox22.Controls.Add(this.Button22);
            this.groupBox22.Controls.Add(this.Button15);
            this.groupBox22.Controls.Add(this.Button14);
            this.groupBox22.Controls.Add(this.SpeedButton_Write_6B);
            this.groupBox22.Controls.Add(this.SpeedButton_Read_6B);
            this.groupBox22.Controls.Add(this.Edit_Len_6B);
            this.groupBox22.Controls.Add(this.label35);
            this.groupBox22.Controls.Add(this.Edit_StartAddress_6B);
            this.groupBox22.Controls.Add(this.label34);
            this.groupBox22.Controls.Add(this.ComboBox_ID1_6B);
            this.groupBox22.Location = new System.Drawing.Point(328, 314);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(486, 308);
            this.groupBox22.TabIndex = 3;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "读写数据/字节块永久写保护";
            // 
            // Edit_WriteData_6B
            // 
            this.Edit_WriteData_6B.Location = new System.Drawing.Point(179, 85);
            this.Edit_WriteData_6B.Name = "Edit_WriteData_6B";
            this.Edit_WriteData_6B.Size = new System.Drawing.Size(301, 21);
            this.Edit_WriteData_6B.TabIndex = 12;
            this.Edit_WriteData_6B.Text = "0000";
            this.Edit_WriteData_6B.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(6, 88);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(155, 12);
            this.label36.TabIndex = 11;
            this.label36.Text = "写数据：(1-32字节/16进制)";
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 12;
            this.listBox2.Location = new System.Drawing.Point(6, 143);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(474, 160);
            this.listBox2.TabIndex = 10;
            // 
            // Button22
            // 
            this.Button22.Location = new System.Drawing.Point(417, 114);
            this.Button22.Name = "Button22";
            this.Button22.Size = new System.Drawing.Size(61, 23);
            this.Button22.TabIndex = 9;
            this.Button22.Text = "清除显示";
            this.Button22.UseVisualStyleBackColor = true;
            this.Button22.Click += new System.EventHandler(this.Button22_Click);
            // 
            // Button15
            // 
            this.Button15.Location = new System.Drawing.Point(277, 114);
            this.Button15.Name = "Button15";
            this.Button15.Size = new System.Drawing.Size(134, 23);
            this.Button15.TabIndex = 8;
            this.Button15.Text = "检测字节块永久写保护";
            this.Button15.UseVisualStyleBackColor = true;
            this.Button15.Click += new System.EventHandler(this.Button15_Click);
            // 
            // Button14
            // 
            this.Button14.Location = new System.Drawing.Point(170, 114);
            this.Button14.Name = "Button14";
            this.Button14.Size = new System.Drawing.Size(101, 23);
            this.Button14.TabIndex = 7;
            this.Button14.Text = "永久写保护";
            this.Button14.UseVisualStyleBackColor = true;
            this.Button14.Click += new System.EventHandler(this.Button14_Click);
            // 
            // SpeedButton_Write_6B
            // 
            this.SpeedButton_Write_6B.Location = new System.Drawing.Point(89, 114);
            this.SpeedButton_Write_6B.Name = "SpeedButton_Write_6B";
            this.SpeedButton_Write_6B.Size = new System.Drawing.Size(75, 23);
            this.SpeedButton_Write_6B.TabIndex = 6;
            this.SpeedButton_Write_6B.Text = "写数据";
            this.SpeedButton_Write_6B.UseVisualStyleBackColor = true;
            this.SpeedButton_Write_6B.Click += new System.EventHandler(this.SpeedButton_Write_6B_Click);
            // 
            // SpeedButton_Read_6B
            // 
            this.SpeedButton_Read_6B.Location = new System.Drawing.Point(8, 114);
            this.SpeedButton_Read_6B.Name = "SpeedButton_Read_6B";
            this.SpeedButton_Read_6B.Size = new System.Drawing.Size(75, 23);
            this.SpeedButton_Read_6B.TabIndex = 5;
            this.SpeedButton_Read_6B.Text = "读数据";
            this.SpeedButton_Read_6B.UseVisualStyleBackColor = true;
            this.SpeedButton_Read_6B.Click += new System.EventHandler(this.SpeedButton_Read_6B_Click);
            // 
            // Edit_Len_6B
            // 
            this.Edit_Len_6B.Location = new System.Drawing.Point(382, 53);
            this.Edit_Len_6B.MaxLength = 2;
            this.Edit_Len_6B.Name = "Edit_Len_6B";
            this.Edit_Len_6B.Size = new System.Drawing.Size(100, 21);
            this.Edit_Len_6B.TabIndex = 4;
            this.Edit_Len_6B.Text = "12";
            this.Edit_Len_6B.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_Len_6B_KeyPress);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(283, 53);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(161, 24);
            this.label35.TabIndex = 3;
            this.label35.Text = "数据长度：\r\n(1-32/字节/10进制数)      ";
            // 
            // Edit_StartAddress_6B
            // 
            this.Edit_StartAddress_6B.Location = new System.Drawing.Point(143, 53);
            this.Edit_StartAddress_6B.MaxLength = 2;
            this.Edit_StartAddress_6B.Name = "Edit_StartAddress_6B";
            this.Edit_StartAddress_6B.Size = new System.Drawing.Size(100, 21);
            this.Edit_StartAddress_6B.TabIndex = 2;
            this.Edit_StartAddress_6B.Text = "00";
            this.Edit_StartAddress_6B.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(6, 50);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(125, 24);
            this.label34.TabIndex = 1;
            this.label34.Text = "起始/写保护地址：\r\n(00-E9)(16进制数)   ";
            // 
            // ComboBox_ID1_6B
            // 
            this.ComboBox_ID1_6B.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_ID1_6B.FormattingEnabled = true;
            this.ComboBox_ID1_6B.Location = new System.Drawing.Point(6, 17);
            this.ComboBox_ID1_6B.Name = "ComboBox_ID1_6B";
            this.ComboBox_ID1_6B.Size = new System.Drawing.Size(474, 20);
            this.ComboBox_ID1_6B.TabIndex = 0;
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.Edit_ConditionContent_6B);
            this.groupBox21.Controls.Add(this.Edit_Query_StartAddress_6B);
            this.groupBox21.Controls.Add(this.label33);
            this.groupBox21.Controls.Add(this.label32);
            this.groupBox21.Controls.Add(this.Greater_6B);
            this.groupBox21.Controls.Add(this.Less_6B);
            this.groupBox21.Controls.Add(this.Different_6B);
            this.groupBox21.Controls.Add(this.Same_6B);
            this.groupBox21.Location = new System.Drawing.Point(1, 447);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(321, 175);
            this.groupBox21.TabIndex = 2;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "Query Tags by Condition";
            // 
            // Edit_ConditionContent_6B
            // 
            this.Edit_ConditionContent_6B.Location = new System.Drawing.Point(181, 144);
            this.Edit_ConditionContent_6B.MaxLength = 8;
            this.Edit_ConditionContent_6B.Name = "Edit_ConditionContent_6B";
            this.Edit_ConditionContent_6B.Size = new System.Drawing.Size(98, 21);
            this.Edit_ConditionContent_6B.TabIndex = 7;
            this.Edit_ConditionContent_6B.Text = "00";
            this.Edit_ConditionContent_6B.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // Edit_Query_StartAddress_6B
            // 
            this.Edit_Query_StartAddress_6B.Location = new System.Drawing.Point(181, 105);
            this.Edit_Query_StartAddress_6B.MaxLength = 2;
            this.Edit_Query_StartAddress_6B.Name = "Edit_Query_StartAddress_6B";
            this.Edit_Query_StartAddress_6B.Size = new System.Drawing.Size(98, 21);
            this.Edit_Query_StartAddress_6B.TabIndex = 6;
            this.Edit_Query_StartAddress_6B.Text = "0";
            this.Edit_Query_StartAddress_6B.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(9, 147);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(191, 12);
            this.label33.TabIndex = 5;
            this.label33.Text = "条件(<=8个16进制数)：          ";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(8, 108);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(185, 12);
            this.label32.TabIndex = 4;
            this.label32.Text = "标签数据起始地址(0-233)：     ";
            // 
            // Greater_6B
            // 
            this.Greater_6B.AutoSize = true;
            this.Greater_6B.Location = new System.Drawing.Point(163, 68);
            this.Greater_6B.Name = "Greater_6B";
            this.Greater_6B.Size = new System.Drawing.Size(71, 16);
            this.Greater_6B.TabIndex = 3;
            this.Greater_6B.TabStop = true;
            this.Greater_6B.Text = "大于条件";
            this.Greater_6B.UseVisualStyleBackColor = true;
            // 
            // Less_6B
            // 
            this.Less_6B.AutoSize = true;
            this.Less_6B.Location = new System.Drawing.Point(8, 68);
            this.Less_6B.Name = "Less_6B";
            this.Less_6B.Size = new System.Drawing.Size(71, 16);
            this.Less_6B.TabIndex = 2;
            this.Less_6B.TabStop = true;
            this.Less_6B.Text = "小于条件";
            this.Less_6B.UseVisualStyleBackColor = true;
            // 
            // Different_6B
            // 
            this.Different_6B.AutoSize = true;
            this.Different_6B.Location = new System.Drawing.Point(163, 30);
            this.Different_6B.Name = "Different_6B";
            this.Different_6B.Size = new System.Drawing.Size(83, 16);
            this.Different_6B.TabIndex = 1;
            this.Different_6B.TabStop = true;
            this.Different_6B.Text = "与条件不同";
            this.Different_6B.UseVisualStyleBackColor = true;
            // 
            // Same_6B
            // 
            this.Same_6B.AutoSize = true;
            this.Same_6B.Location = new System.Drawing.Point(8, 30);
            this.Same_6B.Name = "Same_6B";
            this.Same_6B.Size = new System.Drawing.Size(83, 16);
            this.Same_6B.TabIndex = 0;
            this.Same_6B.TabStop = true;
            this.Same_6B.Text = "与条件相同";
            this.Same_6B.UseVisualStyleBackColor = true;
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.SpeedButton_Query_6B);
            this.groupBox20.Controls.Add(this.Bycondition_6B);
            this.groupBox20.Controls.Add(this.Byone_6B);
            this.groupBox20.Controls.Add(this.ComboBox_IntervalTime_6B);
            this.groupBox20.Controls.Add(this.label31);
            this.groupBox20.Location = new System.Drawing.Point(1, 314);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(321, 132);
            this.groupBox20.TabIndex = 1;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "询查标签";
            // 
            // SpeedButton_Query_6B
            // 
            this.SpeedButton_Query_6B.Enabled = false;
            this.SpeedButton_Query_6B.Location = new System.Drawing.Point(213, 64);
            this.SpeedButton_Query_6B.Name = "SpeedButton_Query_6B";
            this.SpeedButton_Query_6B.Size = new System.Drawing.Size(102, 49);
            this.SpeedButton_Query_6B.TabIndex = 4;
            this.SpeedButton_Query_6B.Text = "单张查询";
            this.SpeedButton_Query_6B.UseVisualStyleBackColor = true;
            this.SpeedButton_Query_6B.Click += new System.EventHandler(this.SpeedButton_Query_6B_Click);
            // 
            // Bycondition_6B
            // 
            this.Bycondition_6B.AutoSize = true;
            this.Bycondition_6B.Location = new System.Drawing.Point(8, 97);
            this.Bycondition_6B.Name = "Bycondition_6B";
            this.Bycondition_6B.Size = new System.Drawing.Size(83, 16);
            this.Bycondition_6B.TabIndex = 3;
            this.Bycondition_6B.TabStop = true;
            this.Bycondition_6B.Text = "有条件查询";
            this.Bycondition_6B.UseVisualStyleBackColor = true;
            this.Bycondition_6B.CheckedChanged += new System.EventHandler(this.Bycondition_6B_CheckedChanged);
            // 
            // Byone_6B
            // 
            this.Byone_6B.AutoSize = true;
            this.Byone_6B.Location = new System.Drawing.Point(8, 64);
            this.Byone_6B.Name = "Byone_6B";
            this.Byone_6B.Size = new System.Drawing.Size(71, 16);
            this.Byone_6B.TabIndex = 2;
            this.Byone_6B.TabStop = true;
            this.Byone_6B.Text = "单张查询";
            this.Byone_6B.UseVisualStyleBackColor = true;
            this.Byone_6B.CheckedChanged += new System.EventHandler(this.Byone_6B_CheckedChanged);
            // 
            // ComboBox_IntervalTime_6B
            // 
            this.ComboBox_IntervalTime_6B.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_IntervalTime_6B.FormattingEnabled = true;
            this.ComboBox_IntervalTime_6B.Location = new System.Drawing.Point(101, 14);
            this.ComboBox_IntervalTime_6B.Name = "ComboBox_IntervalTime_6B";
            this.ComboBox_IntervalTime_6B.Size = new System.Drawing.Size(214, 20);
            this.ComboBox_IntervalTime_6B.TabIndex = 1;
            this.ComboBox_IntervalTime_6B.SelectedIndexChanged += new System.EventHandler(this.ComboBox_IntervalTime_SelectedIndexChanged);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(6, 17);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(113, 12);
            this.label31.TabIndex = 0;
            this.label31.Text = "询查标签间隔时间：";
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.ListView_ID_6B);
            this.groupBox19.Location = new System.Drawing.Point(1, 3);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(813, 309);
            this.groupBox19.TabIndex = 0;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "标签显示";
            // 
            // ListView_ID_6B
            // 
            this.ListView_ID_6B.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.ListView_ID_6B.AllowDrop = true;
            this.ListView_ID_6B.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7});
            this.ListView_ID_6B.FullRowSelect = true;
            this.ListView_ID_6B.GridLines = true;
            this.ListView_ID_6B.HotTracking = true;
            this.ListView_ID_6B.HoverSelection = true;
            this.ListView_ID_6B.Location = new System.Drawing.Point(6, 20);
            this.ListView_ID_6B.Name = "ListView_ID_6B";
            this.ListView_ID_6B.Size = new System.Drawing.Size(801, 283);
            this.ListView_ID_6B.TabIndex = 0;
            this.ListView_ID_6B.UseCompatibleStateImageBehavior = false;
            this.ListView_ID_6B.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "序号";
            this.columnHeader5.Width = 50;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "ID号";
            this.columnHeader6.Width = 600;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "次数";
            this.columnHeader7.Width = 90;
            // 
            // StatusBar1
            // 
            this.StatusBar1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.StatusBar1.Location = new System.Drawing.Point(0, 651);
            this.StatusBar1.Name = "StatusBar1";
            this.StatusBar1.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
            this.TStatusPanel,
            this.Port,
            this.Manufacturername});
            this.StatusBar1.ShowPanels = true;
            this.StatusBar1.Size = new System.Drawing.Size(828, 20);
            this.StatusBar1.SizingGrip = false;
            this.StatusBar1.TabIndex = 26;
            this.StatusBar1.Text = "StatusBar1";
            // 
            // TStatusPanel
            // 
            this.TStatusPanel.Name = "TStatusPanel";
            this.TStatusPanel.Width = 740;
            // 
            // Port
            // 
            this.Port.MinWidth = 66;
            this.Port.Name = "Port";
            this.Port.Text = "Port:";
            // 
            // Manufacturername
            // 
            this.Manufacturername.Name = "Manufacturername";
            this.Manufacturername.Text = "statusManufacturer nameBarPanel1";
            // 
            // Timer_Test_
            // 
            this.Timer_Test_.Tick += new System.EventHandler(this.Timer_Test__Tick);
            // 
            // Timer_G2_Read
            // 
            this.Timer_G2_Read.Interval = 200;
            this.Timer_G2_Read.Tick += new System.EventHandler(this.Timer_G2_Read_Tick);
            // 
            // Timer_G2_Alarm
            // 
            this.Timer_G2_Alarm.Tick += new System.EventHandler(this.Timer_G2_Alarm_Tick);
            // 
            // Timer_Test_6B
            // 
            this.Timer_Test_6B.Tick += new System.EventHandler(this.Timer_Test_6B_Tick);
            // 
            // Timer_6B_Read
            // 
            this.Timer_6B_Read.Tick += new System.EventHandler(this.Timer_6B_Read_Tick);
            // 
            // Timer_6B_Write
            // 
            this.Timer_6B_Write.Tick += new System.EventHandler(this.Timer_6B_Write_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(828, 671);
            this.Controls.Add(this.StatusBar1);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "UHFReader09CSHarp V1.6";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.tabControl1.ResumeLayout(false);
            this.TabSheet_CMD.ResumeLayout(false);
            this.groupBox24.ResumeLayout(false);
            this.groupBox24.PerformLayout();
            this.groupBox23.ResumeLayout(false);
            this.groupBox23.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox30.ResumeLayout(false);
            this.groupBox30.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.TabSheet_EPCC1G2.ResumeLayout(false);
            this.groupBox31.ResumeLayout(false);
            this.groupBox31.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox33.ResumeLayout(false);
            this.groupBox33.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.TabSheet_6B.ResumeLayout(false);
            this.groupBox22.ResumeLayout(false);
            this.groupBox22.PerformLayout();
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            this.groupBox19.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.TStatusPanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Port)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Manufacturername)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage TabSheet_CMD;
        internal System.Windows.Forms.StatusBar StatusBar1;
        private System.Windows.Forms.StatusBarPanel TStatusPanel;
        private System.Windows.Forms.StatusBarPanel Port;
        private System.Windows.Forms.StatusBarPanel Manufacturername;
        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.Button ClosePort;
        internal System.Windows.Forms.Button OpenPort;
        internal System.Windows.Forms.TextBox Edit_CmdComAddr;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.ComboBox ComboBox_COM;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.TabPage TabSheet_EPCC1G2;
        private System.Windows.Forms.TabPage TabSheet_6B;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox ComboBox_AlreadyOpenCOM;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox Edit_dmaxfre;
        private System.Windows.Forms.TextBox Edit_powerdBm;
        private System.Windows.Forms.TextBox Edit_Version;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Edit_dminfre;
        private System.Windows.Forms.TextBox Edit_ComAdr;
        private System.Windows.Forms.TextBox Edit_Type;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button Button3;
        private System.Windows.Forms.TextBox Edit_scantime;
        private System.Windows.Forms.CheckBox EPCC1G2;
        private System.Windows.Forms.CheckBox ISO180006B;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox ComboBox_PowerDbm;
        private System.Windows.Forms.TextBox Edit_NewComAdr;
        private System.Windows.Forms.ComboBox ComboBox_dmaxfre;
        private System.Windows.Forms.ComboBox ComboBox_dminfre;
        private System.Windows.Forms.Button Button1;
        private System.Windows.Forms.Button Button5;
        private System.Windows.Forms.ComboBox ComboBox_scantime;
        private System.Windows.Forms.ComboBox ComboBox_baud;
        private System.Windows.Forms.CheckBox CheckBox_SameFre;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.RadioButton C_TID;
        private System.Windows.Forms.RadioButton C_EPC;
        private System.Windows.Forms.RadioButton C_Reserve;
        private System.Windows.Forms.RadioButton C_User;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button Button_BlockErase;
        private System.Windows.Forms.Button Button_DataWrite;
        private System.Windows.Forms.Button SpeedButton_Read_G2;
        private System.Windows.Forms.TextBox Edit_WriteData;
        private System.Windows.Forms.TextBox Edit_AccessCode2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox Edit_WordPtr;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.ComboBox ComboBox_EPC1;
        private System.Windows.Forms.RadioButton AlwaysNot;
        private System.Windows.Forms.RadioButton Always;
        private System.Windows.Forms.RadioButton Proect;
        private System.Windows.Forms.RadioButton NoProect;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.RadioButton AccessCode;
        private System.Windows.Forms.RadioButton DestroyCode;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.RadioButton P_User;
        private System.Windows.Forms.RadioButton P_TID;
        private System.Windows.Forms.RadioButton P_EPC;
        private System.Windows.Forms.RadioButton P_Reserve;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.RadioButton Always2;
        private System.Windows.Forms.RadioButton Proect2;
        private System.Windows.Forms.RadioButton NoProect2;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.RadioButton AlwaysNot2;
        private System.Windows.Forms.Button Button_SetProtectState;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.ComboBox ComboBox_IntervalTime;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button Button_DestroyCard;
        private System.Windows.Forms.TextBox Edit_DestroyCode;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox ComboBox_EPC3;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Button Button_WriteEPC_G2;
        private System.Windows.Forms.TextBox Edit_AccessCode3;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox Edit_WriteEPC;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Button Button_CheckReadProtected_G2;
        private System.Windows.Forms.Button Button_RemoveReadProtect_G2;
        private System.Windows.Forms.Button Button_SetMultiReadProtect_G2;
        private System.Windows.Forms.Button Button_SetReadProtect_G2;
        private System.Windows.Forms.TextBox Edit_AccessCode4;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ComboBox ComboBox_EPC4;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.ComboBox ComboBox_EPC5;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.TextBox Edit_AccessCode5;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.RadioButton NoAlarm_G2;
        private System.Windows.Forms.RadioButton Alarm_G2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button Button_SetEASAlarm_G2;
        private System.Windows.Forms.Label Label_Alarm;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.ComboBox ComboBox_BlockNum;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox ComboBox_EPC6;
        private System.Windows.Forms.Button Button_LockUserBlock_G2;
        private System.Windows.Forms.TextBox Edit_AccessCode6;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.ListView ListView_ID_6B;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.Button SpeedButton_Query_6B;
        private System.Windows.Forms.RadioButton Bycondition_6B;
        private System.Windows.Forms.RadioButton Byone_6B;
        private System.Windows.Forms.ComboBox ComboBox_IntervalTime_6B;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.TextBox Edit_ConditionContent_6B;
        private System.Windows.Forms.TextBox Edit_Query_StartAddress_6B;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.RadioButton Greater_6B;
        private System.Windows.Forms.RadioButton Less_6B;
        private System.Windows.Forms.RadioButton Different_6B;
        private System.Windows.Forms.RadioButton Same_6B;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.TextBox Edit_StartAddress_6B;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.ComboBox ComboBox_ID1_6B;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Button Button22;
        private System.Windows.Forms.Button Button15;
        private System.Windows.Forms.Button Button14;
        private System.Windows.Forms.Button SpeedButton_Write_6B;
        private System.Windows.Forms.Button SpeedButton_Read_6B;
        private System.Windows.Forms.TextBox Edit_Len_6B;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Timer Timer_Test_;
        private System.Windows.Forms.ComboBox ComboBox_EPC2;
        private System.Windows.Forms.Timer Timer_G2_Read;
        private System.Windows.Forms.Timer Timer_G2_Alarm;
        private System.Windows.Forms.ListView ListView1_EPC;
        private System.Windows.Forms.ColumnHeader listViewCol_Number;
        private System.Windows.Forms.ColumnHeader listViewCol_ID;
        private System.Windows.Forms.ColumnHeader listViewCol_Length;
        private System.Windows.Forms.ColumnHeader listViewCol_Times;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Timer Timer_Test_6B;
        private System.Windows.Forms.Timer Timer_6B_Read;
        private System.Windows.Forms.TextBox Edit_WriteData_6B;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Timer Timer_6B_Write;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox groupBox30;
        private System.Windows.Forms.RadioButton radioButton_band4;
        private System.Windows.Forms.RadioButton radioButton_band3;
        private System.Windows.Forms.RadioButton radioButton_band2;
        private System.Windows.Forms.RadioButton radioButton_band1;
        private System.Windows.Forms.GroupBox groupBox31;
        private System.Windows.Forms.TextBox maskLen_textBox;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox maskadr_textbox;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.ComboBox ComboBox_baud2;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Button BlockWrite;
        private System.Windows.Forms.RadioButton radioButton_band5;
        private System.Windows.Forms.CheckBox CheckBox_TID;
        private System.Windows.Forms.GroupBox groupBox33;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox textBox_pc;
        private System.Windows.Forms.CheckBox checkBox_pc;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label37;
    }
}

