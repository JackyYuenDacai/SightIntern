//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by UHFReader.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_UHFReader_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDC_COMBO2                      1001
#define IDC_EDIT1                       1002
#define IDC_COMBO3                      1003
#define IDC_BUTTON1                     1004
#define IDC_BUTTON2                     1005
#define IDC_EDIT2                       1006
#define IDC_EDIT3                       1007
#define IDC_CHECK1                      1008
#define IDC_CHECK2                      1009
#define IDC_EDIT4                       1010
#define IDC_EDIT5                       1011
#define IDC_EDIT6                       1012
#define IDC_EDIT7                       1013
#define IDC_EDIT8                       1014
#define IDC_BUTTON3                     1015
#define IDC_COMBO4                      1016
#define IDC_BUTTON4                     1017
#define IDC_BUTTON5                     1018
#define IDC_EDIT9                       1019
#define IDC_COMBO5                      1020
#define IDC_COMBO6                      1021
#define IDC_COMBO7                      1022
#define IDC_RADIO1                      1023
#define IDC_RADIO2                      1024
#define IDC_RADIO3                      1025
#define IDC_RADIO4                      1026
#define IDC_COMBO8                      1027
#define IDC_COMBO9                      1028
#define IDC_CHECK3                      1029
#define IDC_BUTTON6                     1030
#define IDC_BUTTON7                     1031
#define IDC_LIST2                       1032
#define IDC_BUTTON8                     1033
#define IDC_BUTTON9                     1034
#define IDC_EDIT10                      1035
#define IDC_COMBO11                     1036
#define IDC_EDIT11                      1037
#define IDC_EDIT12                      1038
#define IDC_EDIT13                      1039
#define IDC_COMBO12                     1040
#define IDC_EDIT14                      1041
#define IDC_BUTTON10                    1042
#define IDC_BUTTON11                    1043
#define IDC_LIST1                       1044

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1045
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
